//
//  KAlert.h
//  KAlert
//
//  Created by Apple on 15/10/19.
//  Copyright © 2019 Konstant info Solutions Pvt. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for KAlert.
FOUNDATION_EXPORT double KAlertVersionNumber;

//! Project version string for KAlert.
FOUNDATION_EXPORT const unsigned char KAlertVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KAlert/PublicHeader.h>


